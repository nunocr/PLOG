:- ['interface.pl',
	'board.pl',
	'logic.pl'
	].